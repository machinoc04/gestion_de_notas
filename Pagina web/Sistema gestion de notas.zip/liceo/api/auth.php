<?php
require 'db.php';

function inData() {
  $raw = file_get_contents('php://input');
  $j = json_decode($raw, true);
  if (is_array($j)) return $j;
  if (!empty($_POST)) return $_POST;
  if (!empty($_GET))  return $_GET;
  return [];
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';
$data   = inData();

/* ---------- REGISTER ---------- */
if ($action === 'register') {
  $username  = trim($data['username']  ?? '');
  $password  = (string)($data['password'] ?? '');
  $full_name = trim($data['full_name'] ?? '');
  $role      = trim($data['role']      ?? 'docente');

  if ($username === '' || $password === '' || $full_name === '') {
    jsonOut(['error'=>'missing fields','need'=>['username','password','full_name']], 400);
  }

  try {
    // Verificar duplicados
    $chk = $pdo->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
    $chk->execute([$username]);
    if ($chk->fetch()) {
      jsonOut(['error'=>'El nombre de usuario ya existe'], 409);
    }

    $hash = password_hash($password, PASSWORD_BCRYPT);
    $stmt = $pdo->prepare("INSERT INTO users(username,password_hash,full_name,role) VALUES (?,?,?,?)");
    $stmt->execute([$username,$hash,$full_name,$role]);

    jsonOut(['ok'=>true,'id'=>$pdo->lastInsertId()]);
  } catch (PDOException $e) {
    if ((int)$e->getCode() === 23000) { // UNIQUE constraint
      jsonOut(['error'=>'Usuario ya existe'], 409);
    }
    jsonOut(['error'=>'DB error: '.$e->getMessage()], 500);
  }
}

/* ---------- LOGIN ---------- */
if ($action === 'login') {
  $username = $data['username'] ?? null;
  $password = $data['password'] ?? null;
  if (!$username || !$password) {
    jsonOut(['error'=>'missing fields','need'=>['username','password']], 400);
  }
  $stmt = $pdo->prepare("SELECT * FROM users WHERE username=?");
  $stmt->execute([$username]);
  $u = $stmt->fetch();
  if ($u && password_verify($password, $u['password_hash'])) {
    session_start();
    $_SESSION['uid'] = $u['id'];
    jsonOut(['ok'=>true,'user'=>['id'=>$u['id'],'full_name'=>$u['full_name'],'role'=>$u['role']]]);
  }
  jsonOut(['error'=>'invalid'], 401);
}

/* ---------- LOGOUT ---------- */
if ($action === 'logout') {
  session_start();
  session_destroy();
  jsonOut(['ok'=>true]);
}

/* ---------- WHOAMI ---------- */
if ($action === 'whoami') {
  session_start();
  if (!empty($_SESSION['uid'])) {
    jsonOut(['ok'=>true,'uid'=>$_SESSION['uid']]);
  }
  jsonOut(['ok'=>false], 401);
}

/* ---------- DEFAULT ---------- */
jsonOut(['error'=>'unknown action'], 400);
if (isset($_GET['ping'])) { echo 'PONG '.__FILE__; exit; }