<?php
require 'db.php';
$action = $_GET['action'] ?? '';

if ($action==='bootstrap'){
  $course_id  = (int)($_GET['course_id'] ?? 0);
  $subject_id = (int)($_GET['subject_id'] ?? 0);
  if(!$course_id || !$subject_id) jsonOut(['error'=>'missing params'],400);

  // obtener course_subject_id
  $st = $pdo->prepare("SELECT id FROM course_subjects WHERE course_id=? AND subject_id=?");
  $st->execute([$course_id,$subject_id]);
  $cs = $st->fetch();
  if(!$cs) jsonOut(['error'=>'course+subject not linked'],404);
  $csid = (int)$cs['id'];

  // estudiantes del curso
  $st = $pdo->prepare("SELECT id, full_name AS name FROM students WHERE course_id=? ORDER BY full_name");
  $st->execute([$course_id]);
  $students = $st->fetchAll();

  // items de notas existentes
  $st = $pdo->prepare("SELECT id, name, max_score FROM grade_items WHERE course_subject_id=? ORDER BY id");
  $st->execute([$csid]);
  $items = $st->fetchAll();

  // calificaciones existentes
  $st = $pdo->prepare("SELECT student_id, grade_item_id, score FROM grades WHERE grade_item_id IN (
                         SELECT id FROM grade_items WHERE course_subject_id=?
                       )");
  $st->execute([$csid]);
  $grades = $st->fetchAll();

  jsonOut([
    'ok'=>true,
    'course_subject_id'=>$csid,
    'students'=>$students,
    'grade_items'=>$items,
    'grades'=>$grades
  ]);
}

if ($action==='create_item'){
  $d = json_decode(file_get_contents('php://input'), true) ?? $_POST;
  $csid = (int)($d['course_subject_id'] ?? 0);
  $name = trim($d['name'] ?? '');
  $max  = (float)($d['max_score'] ?? 100);
  $date = $d['date'] ?? date('Y-m-d');
  if(!$csid || $name==='') jsonOut(['error'=>'missing fields'],400);

  $st=$pdo->prepare("INSERT INTO grade_items(course_subject_id,name,max_score,date) VALUES (?,?,?,?)");
  $st->execute([$csid,$name,$max,$date]);
  jsonOut(['ok'=>true,'id'=>$pdo->lastInsertId()]);
}

if ($action==='save_scores'){
  $d = json_decode(file_get_contents('php://input'), true) ?? $_POST;
  $item = (int)($d['grade_item_id'] ?? 0);
  $scores = $d['scores'] ?? [];
  if(!$item) jsonOut(['error'=>'grade_item_id required'],400);

  $pdo->beginTransaction();
  $ins = $pdo->prepare("INSERT INTO grades(grade_item_id,student_id,score)
                        VALUES (?,?,?)
                        ON DUPLICATE KEY UPDATE score=VALUES(score)");
  foreach($scores as $s){
    $ins->execute([$item,(int)$s['student_id'],(float)$s['score']]);
  }
  $pdo->commit();
  jsonOut(['ok'=>true,'count'=>count($scores)]);
}

jsonOut(['error'=>'unknown action'],400);
