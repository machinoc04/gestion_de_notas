<?php
require_once __DIR__ . '/db.php';   // importante: require_once para no duplicar funciones

$action = $_GET['action'] ?? '';

if ($action === 'filters') {
    // 🔹 Traer todos los cursos
    $stmt = $pdo->query("SELECT id, name FROM courses ORDER BY name");
    $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
    jsonOut(['ok' => true, 'courses' => $courses]);
}

if ($action === 'subjects_by_course') {
    $courseId = intval($_GET['course_id'] ?? 0);

    if ($courseId <= 0) {
        jsonOut(['ok' => false, 'error' => 'course_id requerido'], 400);
    }

    // 🔹 Traer materias según curso
    $stmt = $pdo->prepare("
        SELECT s.id, s.name 
        FROM course_subjects cs
        INNER JOIN subjects s ON s.id = cs.subject_id
        WHERE cs.course_id = ?
        ORDER BY s.name
    ");
    $stmt->execute([$courseId]);
    $subjects = $stmt->fetchAll(PDO::FETCH_ASSOC);

    jsonOut(['ok' => true, 'subjects' => $subjects]);
}

// 🔹 Si no hay acción válida
jsonOut(['ok' => false, 'error' => 'Acción inválida'], 400);
