<?php
require_once 'db.php'; // trae $pdo y jsonOut()

function inData() {
  $raw = file_get_contents('php://input');
  $j = json_decode($raw, true);
  if (is_array($j)) return $j;
  if (!empty($_POST)) return $_POST;
  if (!empty($_GET)) return $_GET;
  return [];
}

function normalizeDate($s) {
  $s = trim((string)$s);
  // dd/mm/yyyy -> yyyy-mm-dd
  if (preg_match('~^(\d{2})/(\d{2})/(\d{4})$~', $s, $m)) {
    return sprintf('%04d-%02d-%02d', $m[3], $m[2], $m[1]);
  }
  // yyyy-mm-dd
  if (preg_match('~^\d{4}-\d{2}-\d{2}$~', $s)) return $s;
  return '';
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';
$d = inData();

/**
 * GET /api/attendance.php?action=bootstrap&course_id=1&subject_id=1&date=2025-08-17
 * o con fecha dd/mm/yyyy
 */
if ($action === 'bootstrap') {
  $course_id  = isset($d['course_id'])  ? (int)$d['course_id']  : 0;
  $subject_id = isset($d['subject_id']) ? (int)$d['subject_id'] : 0;

  $dateIn = $d['date'] ?? date('Y-m-d');
  $date   = normalizeDate($dateIn);
  if ($date === '') $date = date('Y-m-d');

  if (!$course_id || !$subject_id) {
    jsonOut(['ok'=>false,'error'=>'course_id/subject_id required'], 400);
  }

  // 1) Validar vínculo curso+materia y obtener course_subject_id
  $stmt = $pdo->prepare("SELECT id FROM course_subjects WHERE course_id=? AND subject_id=? LIMIT 1");
  $stmt->execute([$course_id, $subject_id]);
  $cs = $stmt->fetch(PDO::FETCH_ASSOC);
  if (!$cs) {
    jsonOut(['ok'=>false,'error'=>'course+subject not linked'], 400);
  }
  $course_subject_id = (int)$cs['id'];

  // 2) Traer estudiantes del curso
  $stmt = $pdo->prepare("
    SELECT id,
           CONCAT_WS(' ', first_name, last_name) AS name
    FROM students
    WHERE course_id = ?
    ORDER BY last_name, first_name
  ");
  $stmt->execute([$course_id]);
  $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

  // 3) Traer asistencia existente para ese día y vínculo
  $stmt = $pdo->prepare("
    SELECT student_id, status, notes
    FROM attendance
    WHERE course_subject_id = ? AND date = ?
  ");
  $stmt->execute([$course_subject_id, $date]);
  $attRows = $stmt->fetchAll(PDO::FETCH_ASSOC);

  // Mapear por student_id
  $attendance = [];
  foreach ($attRows as $r) {
    $attendance[(int)$r['student_id']] = [
      'status' => $r['status'],
      'notes'  => $r['notes']
    ];
  }

  jsonOut([
    'ok' => true,
    'course_subject_id' => $course_subject_id,
    'date' => $date,
    'students' => $students,
    'attendance' => $attendance
  ]);
}

/**
 * POST /api/attendance.php?action=save
 * body admite:
 *  - { course_subject_id, date, items:[{student_id, status, notes}] }
 *  - { course_id, subject_id, date, items:[...] }  -> resuelve course_subject_id internamente
 */
if ($action === 'save') {
  // Permite ambas firmas
  $cs_id = isset($d['course_subject_id']) ? (int)$d['course_subject_id'] : 0;

  // Normaliza fecha
  $dateIn = $d['date'] ?? date('Y-m-d');
  $date   = normalizeDate($dateIn);
  if ($date === '') $date = date('Y-m-d');

  $items = $d['items'] ?? [];
  if (!is_array($items)) $items = [];

  // Si no llega course_subject_id, intenta con course_id + subject_id
  if ($cs_id <= 0) {
    $course_id  = isset($d['course_id'])  ? (int)$d['course_id']  : 0;
    $subject_id = isset($d['subject_id']) ? (int)$d['subject_id'] : 0;
    if ($course_id > 0 && $subject_id > 0) {
      $q = $pdo->prepare("SELECT id FROM course_subjects WHERE course_id=? AND subject_id=? LIMIT 1");
      $q->execute([$course_id, $subject_id]);
      $row = $q->fetch(PDO::FETCH_ASSOC);
      if ($row) $cs_id = (int)$row['id'];
    }
  }

  if ($cs_id <= 0 || empty($items)) {
    jsonOut(['ok'=>false,'error'=>'invalid payload'], 400);
  }

  // UPSERT con validación de status
  $pdo->beginTransaction();
  try {
    $sql = "
      INSERT INTO attendance (course_subject_id, student_id, date, status, notes)
      VALUES (:cs, :sid, :dt, :st, :nt)
      ON DUPLICATE KEY UPDATE status = VALUES(status), notes = VALUES(notes)
    ";
    $stmt = $pdo->prepare($sql);

    foreach ($items as $row) {
      $sid = (int)($row['student_id'] ?? 0);
      if ($sid <= 0) continue;

      $st  = strtolower(trim($row['status'] ?? 'presente'));
      if (!in_array($st, ['presente','ausente','tarde'], true)) $st = 'presente';

      $nt  = (string)($row['notes'] ?? '');

      $stmt->execute([
        ':cs'  => $cs_id,
        ':sid' => $sid,
        ':dt'  => $date,
        ':st'  => $st,
        ':nt'  => $nt
      ]);
    }

    $pdo->commit();
    jsonOut(['ok'=>true]);
  } catch (\Throwable $e) {
    $pdo->rollBack();
    jsonOut(['ok'=>false,'error'=>$e->getMessage()], 500);
  }
}

jsonOut(['ok'=>false,'error'=>'unknown action'], 400);
