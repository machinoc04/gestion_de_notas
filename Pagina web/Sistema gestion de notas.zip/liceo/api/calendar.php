<?php
// api/calendar.php
require_once __DIR__ . '/db.php';

$action = $_GET['action'] ?? '';

// Leer cuerpo JSON / POST / GET
function inAll() {
    $raw = file_get_contents('php://input');
    $j   = json_decode($raw, true);
    if (is_array($j) && count($j)) return $j;
    if (!empty($_POST)) return $_POST;
    if (!empty($_GET))  return $_GET;
    return [];
}

// Asegura tabla (idempotente)
$pdo->exec("
CREATE TABLE IF NOT EXISTS calendar_events (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT NULL,
  type VARCHAR(20) DEFAULT 'otro',
  start DATETIME NOT NULL,
  end   DATETIME NULL,
  all_day TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

// -------- LIST: eventos por rango --------
if ($action === 'list') {
    $from = $_GET['from'] ?? date('Y-m-01');
    $to   = $_GET['to']   ?? date('Y-m-t');
    $st = $pdo->prepare("
        SELECT id, title, description, type, start, end, all_day
        FROM calendar_events
        WHERE (start BETWEEN ? AND ?) OR (end BETWEEN ? AND ?)
        ORDER BY start
    ");
    $st->execute([$from, $to, $from, $to]);
    jsonOut($st->fetchAll());
}

// -------- CREATE --------
if ($action === 'create') {
    $d = inAll();
    $title = trim($d['title'] ?? '');
    $type  = strtolower(trim($d['type'] ?? 'otro'));
    $start = trim($d['start'] ?? '');
    $end   = trim($d['end']   ?? '');
    $desc  = trim($d['description'] ?? '');
    $all   = !empty($d['all_day']) ? 1 : 0;

    if ($title === '' || $start === '') {
        jsonOut(['ok'=>false, 'error'=>'title y start son obligatorios'], 400);
    }

    $st = $pdo->prepare("
        INSERT INTO calendar_events (title, description, type, start, end, all_day)
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $st->execute([$title, $desc, $type, $start, $end ?: null, $all]);
    jsonOut(['ok'=>true, 'id'=>$pdo->lastInsertId()]);
}

// -------- UPDATE --------
if ($action === 'update') {
    $id = (int)($_GET['id'] ?? 0);
    if ($id <= 0) jsonOut(['ok'=>false,'error'=>'id requerido'], 400);

    $d = inAll();
    $title = trim($d['title'] ?? '');
    $type  = strtolower(trim($d['type'] ?? 'otro'));
    $start = trim($d['start'] ?? '');
    $end   = trim($d['end']   ?? '');
    $desc  = trim($d['description'] ?? '');
    $all   = !empty($d['all_day']) ? 1 : 0;

    if ($title === '' || $start === '') {
        jsonOut(['ok'=>false, 'error'=>'title y start son obligatorios'], 400);
    }

    $st = $pdo->prepare("
        UPDATE calendar_events
        SET title=?, description=?, type=?, start=?, end=?, all_day=?
        WHERE id=?
    ");
    $st->execute([$title, $desc, $type, $start, $end ?: null, $all, $id]);
    jsonOut(['ok'=>true, 'rows'=>$st->rowCount()]);
}

// -------- DELETE (opcional) --------
if ($action === 'delete') {
    $id = (int)($_GET['id'] ?? 0);
    if ($id <= 0) jsonOut(['ok'=>false,'error'=>'id requerido'], 400);
    $pdo->prepare("DELETE FROM calendar_events WHERE id=?")->execute([$id]);
    jsonOut(['ok'=>true]);
}

// -------- STATS --------
if ($action === 'stats') {
    $from = $_GET['from'] ?? date('Y-m-01');
    $to   = $_GET['to']   ?? date('Y-m-t');

    $st = $pdo->prepare("
        SELECT LOWER(type) AS t, COUNT(*) n
        FROM calendar_events
        WHERE (start BETWEEN ? AND ?) OR (end BETWEEN ? AND ?)
        GROUP BY LOWER(type)
    ");
    $st->execute([$from,$to,$from,$to]);
    $rows = $st->fetchAll();

    $counts = ['clase'=>0,'reunion'=>0,'examen'=>0,'proyecto'=>0];
    foreach ($rows as $r) {
        if (isset($counts[$r['t']])) $counts[$r['t']] = (int)$r['n'];
    }
    jsonOut(['ok'=>true,'counts'=>$counts,'from'=>$from,'to'=>$to]);
}

jsonOut(['ok'=>false,'error'=>'unknown action'], 400);
