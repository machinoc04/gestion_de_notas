const API_BASE = '/liceo/api/';

async function apiGet(path){
  const r = await fetch(API_BASE + path, {credentials:'include'});
  return r.json();
}

async function apiPost(path, data){
  const r = await fetch(API_BASE + path, {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify(data),
    credentials:'include'
  });
  return r.json();
}