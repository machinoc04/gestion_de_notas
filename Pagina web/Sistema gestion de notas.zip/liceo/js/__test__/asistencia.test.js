// Importamos las funciones desde asistencia.js
const { esc, badge } = require('../asistencia');

// --- Pruebas de esc() ---
test('escapa caracteres < y >', () => {
  expect(esc('<script>')).toBe('&lt;script&gt;');
  expect(esc('Hola > Adiós')).toBe('Hola &gt; Adiós');
});

test('escapa comillas y ampersand', () => {
  expect(esc('"Hola" & Adiós')).toBe('&quot;Hola&quot; &amp; Adiós');
});

// --- Pruebas de badge() ---
test('retorna Presente con "P"', () => {
  expect(badge('P')).toBe('<span class="badge b-ok">Presente</span>');
});

test('retorna Presente con "presente"', () => {
  expect(badge('presente')).toBe('<span class="badge b-ok">Presente</span>');
});

test('retorna Tarde con "t" o "late"', () => {
  expect(badge('t')).toBe('<span class="badge b-late">Tarde</span>');
  expect(badge('late')).toBe('<span class="badge b-late">Tarde</span>');
});

test('retorna Ausente por defecto', () => {
  expect(badge('xyz')).toBe('<span class="badge b-no">Ausente</span>');
  expect(badge('')).toBe('<span class="badge b-no">Ausente</span>');
});
