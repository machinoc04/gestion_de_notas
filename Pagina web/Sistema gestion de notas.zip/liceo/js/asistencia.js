// asistencia.js

/**
 * Escapa caracteres especiales en texto para evitar inyección de HTML
 * @param {string} s - Texto a escapar
 * @returns {string} - Texto seguro para insertar en el DOM
 */
function esc(s = '') { 
  return String(s).replace(/[&<>"]/g, m => (
    { '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;' }[m]
  ));
}

/**
 * Genera un badge (etiqueta visual) para mostrar estado de asistencia
 * @param {string} status - Estado ("presente", "tarde", "ausente", etc.)
 * @returns {string} - HTML del span con la clase correspondiente
 */
function badge(status) {
  const s = (status || '').toLowerCase();
  if (s === 'presente' || s === 'p') {
    return '<span class="badge b-ok">Presente</span>';
  }
  if (s === 'tarde' || s === 'late' || s === 't') {
    return '<span class="badge b-late">Tarde</span>';
  }
  return '<span class="badge b-no">Ausente</span>';
}

// Exportamos para Jest (Node.js)
if (typeof module !== 'undefined') {
  module.exports = { esc, badge };
}
